# Documentation
The API documentation for the workplace api can be found under: `/dist/docs`

# Samples
The project comes with a static version of the workplace environment.
To run the sample environment, make the project folder available on a local webserver.

## Run samples on local apache
Following modules must be enabled: mod_alias, mod_proxy, mod_rewrite

### A) Zipped version
Extract the workplace-api-v.x.x.x.zip to your apache's htdocs folder.

### B) Map project folder
For development you can configure an alias to the project folder (modify the path accordingly) by adding these lines to your httpd.conf (assuming Apache 2.4):
```
Alias /itowp_api C:\projects\itowp_api
<Directory C:\projects\itowp_api>
    Require all granted
    AllowOverride All
</Directory>
```

Workplace sample will be available at `http://localhost/itowp_api/sample`.
If you want to serve from a different directory, you must change the rewrite base in `http://localhost/itowp_api/sample/.htaccess`.

## Sample Apps
Workplace API Test sample can be found under: `/sample/assets/test/api.html`
The app can be started over the apps menu or by using a workplace deeplink:
`http://localhost/workplace/#/connect/api/param=value`

Workplace API Mirror sample can be found under: `/sample/assets/test/mirror.html`

# Configuring your own app
To make your app available in the sample environment, you can edit the file `/sample/assets/test/apps.json`.
Add the following object to the JSON array and modify the properties so it fits your app:
```
{
    "name": "myApp",
    "description": "My App Title",
    "sortPosition": 1,
    "url": "http://example.com/path",
    "multipleWindows": false
}
```
