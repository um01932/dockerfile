# Workplace Messaging API

Include the library `workplace-api.js` into your web application. Either host the library yourself,
or get the latest version from the Workplace Environment.

The library expects an ES6 compatible Promise constructor. On plattforms that no not yet implement ES6 Promises
(Internet Explorer), a polyfill is required, such as [es6-promise](https://github.com/jakearchibald/es6-promise).

```HTML
<script type="text/javascript" src="http://workplace-int.bmwgroup.net/iwp/workplace-api/es6-promise.js"></script>
<script type="text/javascript" src="http://workplace-int.bmwgroup.net/iwp/workplace-api/workplace-api.js"></script>
```
The library supports UMD, so you can also use a CommonJS or asynchronous module loader. Example with requireJS:
```Javascript
define(function(require) {

    var iwp = require('path/to/workplace-api');
    iwp.Messaging.createClient();

});
```

A Typescript Definition File is available in the project repository: `workplace-api.d.ts`.

## Usage
For the Messaging API there are 2 categories of applications: **Hosts** and **Clients**.
In case of the Workplace Environment, the Workplace is a Host and its Apps are Clients.
Typically, when integrating an app into the Workplace, a Client should be created.

### Creating a client
Use the factory function [[Messaging.createClient]] to a [[Client]].

### Workplace API Functions
Use [[Client.callApi]] to call api functions of the host. It will return a promise which resolves to the api functions result.

The Workplace is currently offering these api functions:
* Open an app: `client.callApi('openApp', ['appName'])`. The Promise will resolve with the id of the app instance.
* Connect to an app: `client.callApi('connect', [{id: 'appId'}])`. The Promise will resolve with a new [[Connection]] instance.
* Select a tab:  `client.callApi('selectTab', 'appId')`. Use the id returned by `openApp`.
* Show app support overlay in workplace:
```
client.callApi('showAppSupport', {
  msgType: 'error',
  msgCode: 'ERR102',
  category: 'business',
  msgText: 'Funktionszugriff verweigert',
  appRole: 'Meine Applikationsrolle',
  appState: 'Dialog für Business Objekt erstellen',
  serviceGroup: 'ca-pdm-applikationsserver:global'
});
```


### Refresh
Integrated apps that do not support deeplinks or client side routing, can use the Messaging API to avoid page refreshes.
Therefore the app must register the api function `refresh`.
```JavaScript
client.registerApi('refresh', function(queryParams, hash) {
    // handle query string params
});
```

The workplace deeplink which triggers a refresh on apps is according to the following scheme:
`/#/refresh/appName/:params/:hash`. Params are without leading `?` or `#`.
The parameters are separated by the `~` character.

Example to call the App "api" in the workplace sample:
`/#/refresh/api/param1=value1~param2=value2`

The route `connect` and separator `&` are still supported but deprecated.

### Connecting to other clients
To connect to a client B, a client A can call an api function on the host, called `connect`. Please refer to [[Client.callApi]].

Client A:
```JavaScript
client.callApi('connect', {id: 'clientB'}).then(function(connection) {
    //connection to client B has been established
    connection.callApi('apiFnName', [value1, value2]).then(function(result) {

    });
});
```

When the attempt for a connection is made, client B can register api functions for client A to call. Please refer to [[Connection.registerApi]].
Client B:
```JavaScript
client.onConnect(function(from, connection) {
    //connection
    connection.registerApi('apiFnName', function(param1, param2) {
        return result;
    });
});
```

### Check for workplace environment
The workplace is calling the app with an url parameter `env=workplace`. Use this parameter to check whether
the app is running in the workplace context. Be aware that this is not a replacement for a security check.

```JavaScript
if(Messaging.isWorkplaceEnv()) {
    // running in workplace
};
```

## Changelog

### Version 0.1.6 (15.07.2016)
* Updated Workplace Sample
* Bugfix for removed connections

### Version 0.1.5 (13.07.2016)
* Bugfix for closing client connections on page navigation.

### Version 0.1.4 (30.05.2016)
* Bugfix for api call results that return the value `false`
* Error on origin check will be logged
* Sample for VAAS integration

### Version 0.1.3 (30.03.2016)
* Update Workplace Sample for Deeplink URLs (~ Separator and /refresh route)

### Version 0.1.2 (02.03.2016)
* Support clients that are created asynchronously
* Helper function for workplace environment check: [[Messaging.isWorkplaceEnv]]

### Version 0.1.1 (23.02.2016)
Implemented changes suggested by project FLS:
* [[Messaging.createClient]] is now returning a promise
* [[Messaging.createClient]] now takes a config object which is optional
* [[Client.callApi]] and [[Connection.callApi]] use spread arguments for api function parameters instead of array
* Added sample to check for workplace environment by url parameter `env=workplace`

### Version 0.1.0 (12.02.2016)
Initial Version

## Contributors
* <a href="mailto:Tobias.Straller@nttdata.com">Tobias Straller</a>, NTT Data
