import { Client } from "./Client";
import { Host } from "./Host";
import { IClientConfig } from "./IClientConfig";
import "../polyfills/polyfill-assign";
/**
 * Utility for creating hosts or clients.
 * @author Tobias Straller [Tobias.Straller@nttdata.com]
 *
 */
export declare var Messaging: {
    _VERSION: string;
    /**
     * Setter for the window which is serving as host. Default is the parent window.
     * Only change this in case you have a multi frame setup.
     * @param win
     */
    hostWindow: Window;
    /**
     * Configuration options for the client. For security reasons it is strongly advised to set the configuration.
     * @param {IClientConfig} config
     */
    clientConfig: IClientConfig;
    /**
     * Create a messaging api client
     *
     *      this.createClient(window.parent, {origin: 'http://workplace-int.bmwgroup.net', allowConnectFrom: []}).then(function(client) {
     *          //client is connected
     *          client.registerApi('myApiFunctionName', function() {
     *              //handle api call
     *          });
     *      });
     *
     * @param hostWindow The window which is serving as host. Default is the parent window.
     * @param {IClientConfig} config
     * @returns {Promise<Client>}
     */
    createClient(hostWindow?: Window, config?: IClientConfig): Promise<Client>;
    /**
     * Returns a client. If no client exists yet, a new client will be created.
     */
    getClient(): Promise<Client>;
    /**
     * Create a messaging api host.
     * @returns {Host}
     */
    createHost(): Host;
    /**
     * Utility function to check for a URL parameter value in a query string.
     * @param param
     * @param value
     * @param queryString default is window.location.search
     * @returns {boolean}
     */
    matchUrlParam(param: string, value: string, queryString?: string): boolean;
    /**
     * Checks whether the current browsing context is running in the workplace environment.
     * @returns {boolean}
     */
    isWorkplaceEnv(): boolean;
};
