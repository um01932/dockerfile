# Documentation
The API documentation for the workplace api can be found under: `/dist/docs`

# Samples
The project comes with a static version of the workplace environment.
To run the sample environment, make the project folder available on a local webserver.

## Run samples on local apache
Following modules must be enabled: mod_alias, mod_proxy, mod_rewrite

### A) Zipped version
Extract the workplace-api-v.x.x.x.zip to your apache's htdocs folder.

### B) Map project folder
For development you can configure an alias to the project folder (modify the path accordingly) by adding these lines to your httpd.conf (assuming Apache 2.4):
```
Alias /itowp_api C:\projects\itowp_api
<Directory C:\projects\itowp_api>
    Require all granted
    AllowOverride All
</Directory>
```

Workplace sample will be available at `http://localhost/itowp_api/sample`.
If you want to serve from a different directory, you must change the rewrite base in `http://localhost/itowp_api/sample/.htaccess`.

## Sample Apps
Workplace API Test sample can be found under: `/sample/assets/test/api.html`
The app can be started over the apps menu or by using a workplace deeplink:
`http://localhost/workplace/#/connect/api/param=value`

Workplace API Mirror sample can be found under: `/sample/assets/test/mirror.html`

# Configuring your own app
To make your app available in the sample environment, you can edit the file `/sample/assets/test/apps.json`.
Add the following object to the JSON array and modify the properties so it fits your app:
```
{
    "name": "myApp",
    "description": "My App Title",
    "sortPosition": 1,
    "url": "http://example.com/path",
    "multipleWindows": false
}
```

# Mocking of dependent applications
To mock the api calls from/to another application, the following test pages can be used as a template:
* `/sample/assets/test/api-logger.html`: Use this template to register API functions that your app will be calling. It can return mock data.
* `/sample/assets/test/api-caller.html`: Use this template to open and call API function defined by your app

# VAAS Integration
The WebVis API can be called over Workplace Messaging.
To get an overview of the available API functions, please consult the WebVis Developer Manual.

Example: Adding an URN to the WebVis
```
webvisConnection.callApi('add', 'urn:bmw:prisma:dokuid:47625775');
```
The function `add` is provided by the WebVis API and is directly called over Messaging.

A sample implementation is provided in the app "Visualization" under `/sample/assets/test/visualization`.

The following is demonstrated in the sample app:
* opening and connecting to the app "vaas" (Compare `VisualizationController.js #138-#139`)
* adding a URN to the webvis (Compare `VisualizationController.js #20`)
* setting properties to display a node (Compare `VisualizationController.js #124`)
* selection of nodes (Compare `VisualizationController.js #104-#109`)
* handling events (Compare `VisualizationController.js #140-#141`)
* removing a node (Compare `VisualizationController.js #140-#141`)

## WebVis Events
Events Listeners cannot be registered directly over Messaging, because functions are not transferable over a MessageChannel.
Therefore the app "vaas" assumes the opening app implements an API function called `eventListenerCallback`.
If an event is fired, it will always call this function.

Example `VisualizationController.js #138`:

```
client.callApi('openApp', 'vaas').then(function (id) {
    client.callApi('connect', {id: id}).then(function (connection) {
        connection.registerApi('eventListenerCallback', me.webvisEventListenerCallback.bind(me));
        connection.callApi('registerListener', [EventTypes.NODE_CHANGED, EventTypes.NODE_REMOVED]);
    });
});
```

In the example above, the event listener is registered as API function `eventListenerCallback` as soon as the connection to "vaas" is available.
The subsequent call to `registerListener` is missing the function parameter.

## Running the Visualization Sample App
* Based on WebVis Test App: https://ltvaas1-web.bmwgroup.net/repo/webvis/webvis-app.html
* User must be logged into the B2B Portal prior to calling the sample app (link above)
* User needs access to the VAAS Test Environment (role Vaas_User)

