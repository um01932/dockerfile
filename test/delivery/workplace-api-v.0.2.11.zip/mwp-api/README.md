# myWorkplace API #

## Contents ##
* [Documentation](#documentation)
* [Start](#start)
* [Webcomponents](#webcomponents)
* [Configuring your own app](#configuring-your-own-app)
* [Configuration files](#configuration-files)
* [iFrame Widgets](#iframe-widgets)
* [Splitted App Layoutes](#splitted-app-layouts)
* [VAAS Integration](#vaas-integration)
* [Build](#build)

## Documentation
The API documentation for the workplace api is generated and can be found under: `/dist/doc`.
Also see [doc.md](./doc.md)

## Start
The Workplace API comes with a myWorkplace Test Environment which can be used to test app integration and API calls locally.

 ```
 docker build . -t mwp-api
 docker run -p 8080:80 -d mwp-api
 ```
 
 If you want to use custom configuration, you should mount a volume that contains all of the workplace configuration files:
 
 ```
 docker run -p 8080:80 -d -v `pwd`/sample/assets/test:/usr/local/apache2/htdocs/mwp-api/sample/assets/test mwp-api
 ```
 
 Browser location: [http://localhost:8080/mwp-api/sample/#/](http://localhost:8080/mwp-api/sample/#/)
 
## Webcomponents

The webcomponent's script files and their dependencies are located under `/sample/assets/components`:

### File structure
```
components/
 ├──mycomponent/               * contains dependency files that will be loaded on demand by the seed script (optional)
 └──mycomponent.js             * seed script file that will initialize and load the components
```

### Polyfills

Polyfills are provided by the npm package `@webcomponents/webcomponentsjs`
```
<script src="../node_modules/@webcomponents/webcomponentsjs/custom-elements-es5-adapter.js"></script>
<script src="../node_modules/@webcomponents/webcomponentsjs/webcomponents-bundle.js"></script>
```

### Configuration
Webcomponent widgets are defined in `/sample/assets/test/widgets.json`:
```json
{
    "id": "image1",
    "type": "web-component",
    "title": "My Image Widget",
    "colspan": 4,
    "rowspan": 4,
    "dataUrl": "/components/mwp.js",
    "customSettings": {
      "componentName": "mwp-image",
      "props": {
        "url": "./assets/images/bmw1.jpg",
        "dashboard": "custom"
      }
    }
  }
```
* `dataUrl` URL to the seed script of the webcomponent
* `customSettings.componentName` name of the custom element selector
* `props` a key/value object. For every key, a property will be set on the component instance with the given value

### Workplace API
Webcomponent widgets have access to the Workplace API. A special prop `connection` is set on the component:
```javascript
// stencil.js syntax

@Component({
  tag: 'mwp-custom'
})
export class Custom {

  // connection is a special prop set by myWorkplace
   @Prop() connection: Connection;

  handleClick() {
    this.connection.callApi('openDashboard', {id: 'dashboard-1'});
  }
}
```

## Configuring your own app
To make your app available in the sample environment, you can edit the file `/sample/assets/test/apps.json`.
Add the following object to the JSON array and modify the properties so it fits your app:
```
{
    "name": "myApp",
    "description": "My App Title",
    "sortPosition": 1,
    "url": "http://example.com/path",
    "multipleWindows": false
}
```

## Configuration files

All configuration files are located under `sample/assets/test`

* `apps.json` Configure applications
* `dashboards.json` Create dashboards and add categories, widgets etc. to dashboard
* `widgets.json` Configure widgets
* `user.json` Change user attributes, business roles, etc.
* `appLayouts.json` Configure iframes in app layouts

## Mocking of dependent applications

To mock the api calls from/to another application, the following test pages can be used as a template:
* `/sample/assets/test/api-logger.html`: Use this template to register API functions that your app will be calling. It can return mock data.
* `/sample/assets/test/api-caller.html`: Use this template to open and call API function defined by your app

## iFrame Widgets
The sample features 2 preconfigured iFrame widgets that use Workplace API to communicate with each other.
The widgets are configured in the following file: `/sample/assets/test/widgets.json`

These attributes can be changed:
* `customSettings.title` Title of the widget
* `customSettings.url` URL that will be displayed in the iframe
* `colspan` Number of columns in the dashboard's grid
* `rowspan` Number of rows in the dashboard's grid

The widget IDs have to be added to the dashboard's widget array in the following files:
* `/sample/assets/test/dashboards.json`

Please make sure that your widget ID matches in both files.

## Splitted App Layouts
Layouts are configured in the following file: `/sample/assets/test/appLayouts.json`.
Currently only iFrame Widgets are supported in Layouts.


## VAAS Integration
The WebVis API can be called over Workplace Messaging.
To get an overview of the available API functions, please consult the WebVis Developer Manual.

Example: Adding an URN to the WebVis
```
webvisConnection.callApi('add', 'urn:bmw:prisma:dokuid:47625775');
```
The function `add` is provided by the WebVis API and is directly called over Messaging.

A sample implementation is provided in the app "Visualization" under `/sample/assets/test/visualization`.

The following is demonstrated in the sample app:
* opening and connecting to the app "vaas" (Compare `VisualizationController.js #138-#139`)
* adding a URN to the webvis (Compare `VisualizationController.js #20`)
* setting properties to display a node (Compare `VisualizationController.js #124`)
* selection of nodes (Compare `VisualizationController.js #104-#109`)
* handling events (Compare `VisualizationController.js #140-#141`)
* removing a node (Compare `VisualizationController.js #140-#141`)

### WebVis Events
Events Listeners cannot be registered directly over Messaging, because functions are not transferable over a MessageChannel.
Therefore the app "vaas" assumes the opening app implements an API function called `eventListenerCallback`.
If an event is fired, it will always call this function.

Example `VisualizationController.js #138`:

```
client.callApi('openApp', 'vaas').then(function (id) {
    client.callApi('connect', {id: id}).then(function (connection) {
        connection.registerApi('eventListenerCallback', me.webvisEventListenerCallback.bind(me));
        connection.callApi('registerListener', [EventTypes.NODE_CHANGED, EventTypes.NODE_REMOVED]);
    });
});
```

In the example above, the event listener is registered as API function `eventListenerCallback` as soon as the connection to "vaas" is available.
The subsequent call to `registerListener` is missing the function parameter.

### Running the Visualization Sample App
* Based on WebVis Test App: https://ltvaas1-web.bmwgroup.net/repo/webvis/webvis-app.html
* User must be logged into the B2B Portal prior to calling the sample app (link above)
* User needs access to the VAAS Test Environment (role Vaas_User)

## Build

Requirements: 
* `node v4.x`
* `npm v2.x`

Project uses the build tool [gulp](http://gulpjs.com/).
If you do not have gulp-cli installed, run the following command `npm install -g gulp-cli`.

When building for the first time, run `npm install` on the project root.

To build the library and the api doc run `npm run build` on the project root.
The files will be generated in `/dist`.
An archive containing distribution files will be put under `/delivery`.