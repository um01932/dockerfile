declare module messaging {

    export interface MessagingStatic {
        createClient(hostWindow?:Window, config?:{origin:string, allowConnectFrom:string[]}):Promise<Client>;
        createHost():Host;
        matchUrlParam(param:string, value:string, queryString?:string):boolean;
        isWorkplaceEnv():boolean;
    }

    export interface Client {
        new(hostWindow:Window, config:{origin:string, allowConnectFrom:string[]}):Client;
        hostConnection:Connection;
        onConnect(handler:(from:string, connection:Connection) => void):void;
        offConnect(handler:(from:string, connection:Connection) => void):void;
        callApi(name:string, ...params:any[]):Promise<any>;
        registerApi(name, handler:(...params:any[]) => Promise<any>|any):void;
        destroy():void;
    }

    export interface Host {
        new():Host;
        createConnection(id:string, origin:string, frame:Window):Promise<Connection>;
        getConnection(id:string):Promise<Connection>;
        closeConnection(id:string):void;
        destroy():void;
    }

    export interface Connection {
        port:MessagePort;
        new(port:MessagePort, keepAlive:boolean, onReady?:() => void):Connection;
        callApi(name:string, ...params:any[]):Promise<any>;
        registerApi(name:string, handler:(...params:any[]) => Promise<any>|any):void;
        close():void;
        onClose(handler:(connection:Connection) => void):void;
        offClose(handler:(connection:Connection) => void):void;
    }

}
declare var Messaging:messaging.MessagingStatic;

