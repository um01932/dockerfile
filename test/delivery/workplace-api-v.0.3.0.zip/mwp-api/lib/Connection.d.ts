/**
 * Connection that has a port to an external browsing context.
 * The current context can register api functions for the external context.
 * The current context can call api functions registered by the external context.
 * @author Tobias Straller [Tobias.Straller@nttdata.com]
 */
export declare class Connection {
    /**
     * Error code inidicating that an api function has not been registered for the current connection
     * @type {number}
     */
    static ERROR_CODE_API_FUNCTION_UNAVAILABLE: number;
    /**
     * Connection uses this message port for communication
     */
    port: MessagePort;
    private _messageId;
    private _keepAlive;
    private _deferredMap;
    private _handlers;
    private _onReadyCallback;
    private _closeHandlers;
    private _establishedConnections;
    /**
     * @constructor
     * @param {MessagePort} port
     * @param {boolean} keepAlive Default is false. When false, the connection will be closed after the first api call.
     * @param onReady will be called when the connection has been established
     */
    constructor(port: MessagePort, keepAlive?: boolean, onReady?: () => void);
    /**
     * Make call to an api function available on the connection.
     * Return value is a promise that will resolve with the return value of the api call.
     *
     *          connection.callApi('nameOfApiFn', paramVal1, paramVal2)
     *                      .then(function(result) {
     *                          // call complete
     *                      }).catch(function(reason) {
     *                          // call failed
     *                      });
     *
     * @param {string} name
     * @param {Array} params
     * @param {MessagePort} port
     * @returns {Promise}
     */
    callApi(name: string, ...params: any[]): Promise<any>;
    /**
     * Register an api function by name. The handler will be called with the supplied parameters and optional a port.
     *
     *          connection.registerApi('myApiFnName', function(param1, param2) {
     *              // handle api call and return a value or a promise
     *              return new Promise(function resolve() {}, function reject() {})
     *          });
     *
     *
     * @param {string} name api function is registered with this name
     * @param {Function} handler function will be called
     * @param {MessagePort} [port]
     */
    registerApi(name: string, handler: (...params: any[]) => Promise<any> | any): void;
    /**
     * Check whether an api function is registered on the current connection.
     * @param {string} name api function registered under this name
     */
    isRegisteredApi(name: string): boolean;
    /**
     * Unregister an api function
     * @param {string} name api function registered under this name
     */
    unregisterApi(name: string): void;
    /**
     * Close the connection.
     * Removes handlers, closes port.
     */
    close(): void;
    /**
     * Register a handler which will be called when the connection is closed.
     * The handler will receive the connection as first argument.
     * @param handler
     */
    onClose(handler: (connection: Connection) => void): void;
    /**
     * Unregister a close handler.
     * Also see [[onClose]].
     *
     * @param handler
     */
    offClose(handler?: (connection: Connection) => void): void;
    /**
     * Listener for messages received on the current port
     * @private
     * @param {MessageEvent} event
     */
    private onMessageCallback;
    /**
     * An api call has been answered with a result
     * @private
     * @param {ITransfer} transfer
     */
    private onResult;
    /**
     * An api call has been answered with an error
     * @private
     * @param {ITransfer} transfer
     */
    private onError;
    /**
     * Received a request for an api call. If a handler has been registered, it is called.
     * The result of the function is converted to JSON and asssigned to the result property of the transfer object.
     * If a handler is not registered, the transfer object will be extended with an error property.
     * @private
     * @param {ITransfer} transfer
     */
    private onApiCall;
    /**
     * Returns the next available message id
     * @private
     * @returns {number}
     */
    private _nextMessageId;
}
