import { Connection } from "./Connection";
/**
 * A host can manage connections to multiple clients.
 * The host registers an api function on every client connection, which allows clients to connect to each other.
 * The host acts as a connection broker between the clients und supplies the MessageChannel.
 *
 * Connections can be grouped by supplying a group parameter. Grouped connections can only communicate with connections in the same or in the default group.
 * Groups are used in the workplace to restrict communication between widgets on a dashboard.
 *
 * @author Tobias Straller [Tobias.Straller@nttdata.com]
 */
export declare class Host {
    private _connections;
    private _messageListeners;
    private _promises;
    /**
     * @constructor
     */
    constructor();
    /**
     * Find a connection. If connection is not found in supplied group, then check default group.
     * @param id
     * @param group
     * @returns {any}
     */
    private connectionGet;
    /**
     * Find all connections in all groups
     * @param {string} id
     * @returns {Connection}
     */
    private connectionGetAll;
    /**
     * Add a connection to a group.
     * @param id
     * @param connection
     * @param group
     */
    private connectionAdd;
    /**
     * Remove a connection from a group
     * @param id
     * @param group
     */
    private connectionRemove;
    /**
     * Create a message channel between two clients.
     * @param {string} from
     * @param group
     * @param params
     * @private
     */
    private connect;
    /**
     * Create a message channel between two clients.
     * @param {string} from
     * @param group
     * @param params
     * @private
     */
    private connectAll;
    /**
     * Add a promise that will resolve with a connection
     * @param id
     * @param promise
     * @param group
     * @returns {{resolve: ((connection:Connection)=>void), reject: ((reason:any)=>void)}}
     */
    private addPromise;
    /**
     * Resolve all promises for a certain connection
     * @param id
     * @param connection
     * @param original
     * @param group
     */
    private resolvePromises;
    /**
     * Create a new connection to a client.
     * When creating a connection to an iframe content window, wait for the load event.
     *
     *          frame.addEventListener('load', function() {
     *              host.createConnection('myId', 'http://some.origin.tld', frame.contentWindow)
     *                     .then(function(connection) {
     *                          //client is ready to receive
     *                      });
     *          });
     *
     *
     * @param id used to identify the client
     * @param frame reference to the browsing context, eg. contentWindow of an iframe
     * @param group connections are only allowed to communicate within their connection group or the default group
     * @returns {Connection}
     */
    createConnection(id: string, origin: string, frame: Window, group?: string): Promise<Connection>;
    /**
     * Creates a local connection that is not transfered via postMessage
     * @param {string} id
     * @param {string} group
     */
    createLocalConnection(id: string, group: string): Connection;
    /**
     * Returns the connection for the given client id
     * @param id used to identify the client
     * @param group connections are only allowed to communicate within their connection group or the default group
     * @returns {Connection} returns null if no connection was found for the client id
     */
    getConnection(id: string, group?: string): Promise<Connection>;
    /**
     * Whether the current host has an established connection for the given id
     * @param id
     * @param group connections are only allowed to communicate within their connection group or the default group
     * @returns {boolean}
     */
    hasConnection(id: string, group?: string): boolean;
    /**
     * Close the connection with given id
     * @param id
     */
    closeConnection(id: string, group?: string): void;
    /**
     * Remove a connection
     * @private
     * @param id
     * @param group connections are only allowed to communicate within their connection group or the default group
     */
    private removeConnection;
    /**
     * Destroy the host. Closes all connections
     */
    destroy(): void;
}
