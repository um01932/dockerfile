import { Connection } from "./Connection";
import { IClientConfig } from "./IClientConfig";
/**
 * WorkplaceClient abstracts sending messages to the workplace and workplace apps.
 * It provides an interface that uses promises to react on asynchronous messages.
 * @author Tobias Straller [Tobias.Straller@nttdata.com]
 */
export declare class Client {
    hostConnection: Connection;
    allowConnectFrom: string[];
    private _callback;
    private _origin;
    private _connectHandlers;
    private _clientConnections;
    /**
     *
     * @param hostFrame the window which is serving as host. In the workplace environment this is the parent window
     * @param {IClientConfig} config
     * @param {Function} callback
     * @constructor
     */
    constructor(hostWindow: Window, config: IClientConfig, callback: (client: Client) => void);
    /**
     * Register a handler function in case another client has been connected
     * @param handler Handler function which will receive the id the client and a connection to the client as argument.
     */
    onConnect(handler: (from: string, connection: Connection) => void): void;
    /**
     * Unregister the given connect handler
     * @param handler
     */
    offConnect(handler: (from: string, connection: Connection) => void): void;
    /**
     * Make call to the host api.
     * See also [[Connection.callApi]].
     * @param name
     * @param params
     * @returns {Promise}
     */
    callApi(name: string, ...params: any[]): Promise<any>;
    /**
     * Register an api function at the host connection.
     * See also [[Connection.registerApi]].
     *
     * @param name
     * @param handler
     */
    registerApi(name: any, handler: (...params: any[]) => Promise<any> | any): void;
    /**
     * Unregister an api function at the host connection.
     * See also [[Connection.unregisterApi]].
     *
     * @param name
     */
    unregisterApi(name: any): void;
    /**
     * Disconnect from host
     */
    disconnect(): void;
    /**
     * Destroy the current instance.
     * Remove listeners, close all ports.
     */
    destroy(): void;
    /**
     *
     * @private
     */
    private _connectCallHandler;
}
