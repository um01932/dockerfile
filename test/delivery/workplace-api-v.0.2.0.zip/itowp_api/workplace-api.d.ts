declare module messaging {

    /**
     * Utility class for creating hosts or clients.
     * @author Tobias Straller [Tobias.Straller@nttdata.com]
     *
     */
    export interface MessagingStatic {
        /**
         * Setter for the window which is serving as host. Default is the parent window.
         * Only change this in case you have a multi frame setup.
         * @type {Window}
         */
        hostWindow: Window;
        /**
         * Configuration options for the client. For security reasons it is strongly advised to set the configuration.
         * @type {IClientConfig} config
         */
        clientConfig: IClientConfig;
        /**
         * Create a messaging api client
         *
         *      this.createClient(window.parent, {origin: 'http://workplace-int.bmwgroup.net', allowConnectFrom: []}).then(function(client) {
         *          //client is connected
         *          client.registerApi('myApiFunctionName', function() {
         *              //handle api call
         *          });
         *      });
         *
         * @param hostWindow The window which is serving as host. Default is the parent window.
         * @param {IClientConfig} config
         * @returns {Promise<Client>}
         */
        createClient(hostWindow?: Window, config?: IClientConfig): Promise<Client>;
        /**
         * Returns a client. If no client exists yet, a new client will be created.
         */
        getClient(): Promise<Client>;
        /**
         * Create a messaging api host.
         * @returns {Host}
         */
        createHost(): Host;
        /**
         * Utility function to check for a URL parameter value in a query string.
         * @param param
         * @param value
         * @param queryString default is window.location.search
         * @returns {boolean}
         */
        matchUrlParam(param: string, value: string, queryString?: string): boolean;
        /**
         * Checks whether the current browsing context is running in the workplace environment.
         * @returns {boolean}
         */
        isWorkplaceEnv(): boolean;
    }

    /**
     * WorkplaceClient abstracts sending messages to the workplace and workplace apps.
     * It provides an interface that uses promises to react on asynchronous messages.
     * @author Tobias Straller [Tobias.Straller@nttdata.com]
     */
    export interface Client {
        /**
         *
         * @param hostFrame the window which is serving as host. In the workplace environment this is the parent window
         * @param {IClientConfig} config
         * @param {Function} callback
         * @constructor
         */
        new(hostWindow: Window, config: IClientConfig): Client;
        hostConnection: Connection;
        /**
         * Register a handler function in case another client has been connected
         * @param handler Handler function which will receive the id the client and a connection to the client as argument.
         */
        onConnect(handler: (from: string, connection: Connection) => void): void;
        /**
         * Unregister the given connect handler
         * @param handler
         */
        offConnect(handler: (from: string, connection: Connection) => void): void;
        /**
         * Make call to the host api.
         * See also [[Connection.callApi]].
         * @param name
         * @param params
         * @returns {Promise}
         */
        callApi(name: string, ...params: any[]): Promise<any>;
        /**
         * Register an api function at the host connection.
         * See also [[Connection.registerApi]].
         *
         * @param name
         * @param handler
         */
        registerApi(name, handler: (...params: any[]) => Promise<any> | any): void;
        /**
         * Disconnect from host
         */
        disconnect();
        /**
         * Destroy the current instance.
         * Remove listeners, close all ports.
         */
        destroy(): void;
    }

    /**
     * A host can manage connections to multiple clients.
     * The host registers an api function on every client connection, which allows clients to connect to each other.
     * The host acts as a connection broker between the clients und supplies the MessageChannel.
     *
     * Connections can be grouped by supplying a group parameter. Grouped connections can only communicate with connections in the same or in the default group.
     * Groups are used in the workplace to restrict communication between widgets on a dashboard.
     *
     * @author Tobias Straller [Tobias.Straller@nttdata.com]
     */
    export interface Host {
        new(): Host;
        /**
         * Create a new connection to a client.
         * When creating a connection to an iframe content window, wait for the load event.
         *
         *          frame.addEventListener('load', function() {
         *              host.createConnection('myId', 'http://some.origin.tld', frame.contentWindow)
         *                     .then(function(connection) {
         *                          //client is ready to receive
         *                      });
         *          });
         *
         *
         * @param id used to identify the client
         * @param frame reference to the browsing context, eg. contentWindow of an iframe
         * @param group connections are only allowed to communicate within their connection group or the default group
         * @returns {Connection}
         */
        createConnection(id: string, origin: string, frame: Window, group?: string): Promise<Connection>;

        /**
         * Returns the connection for the given client id
         * @param id used to identify the client
         * @param group connections are only allowed to communicate within their connection group or the default group
         * @returns {Connection} returns null if no connection was found for the client id
         */
        getConnection(id: string, group?: string): Promise<Connection>;

        /**
         * Whether the current host has an established connection for the given id
         * @param id
         * @param group connections are only allowed to communicate within their connection group or the default group
         * @returns {boolean}
         */
        hasConnection(id: string, group?: string): boolean;

        /**
         * Close the connection with given id
         * @param id
         * @param group connections are only allowed to communicate within their connection group or the default group
         */
        closeConnection(id: string, group: string): void;
        /**
         * Destroy the host. Closes all connections
         */
        destroy(): void;

    }


    /**
     * Connection that has a port to an external browsing context.
     * The current context can register api functions for the external context.
     * The current context can call api functions registered by the external context.
     * @author Tobias Straller [Tobias.Straller@nttdata.com]
     */
    export interface Connection {
        /**
         * Connection uses this message port for communication
         */
        port: MessagePort;
        /**
         * @constructor
         * @param {MessagePort} port
         * @param {boolean} keepAlive Default is false. When false, the connection will be closed after the first api call.
         * @param onReady will be called when the connection has been established
         */
        new(port: MessagePort, keepAlive: boolean, onReady?: () => void): Connection;
        /**
         * Make call to an api function available on the connection.
         * Return value is a promise that will resolve with the return value of the api call.
         *
         *          connection.callApi('nameOfApiFn', paramVal1, paramVal2)
         *                      .then(function(result) {
         *                          // call complete
         *                      }).catch(function(reason) {
         *                          // call failed
         *                      });
         *
         * @param {string} name
         * @param {Array} params
         * @param {MessagePort} port
         * @returns {Promise}
         */
        callApi(name: string, ...params: any[]): Promise<any>;
        /**
         * Register an api function by name. The handler will be called with the supplied parameters and optional a port.
         *
         *          connection.registerApi('myApiFnName', function(param1, param2) {
         *              // handle api call and return a value or a promise
         *              return new Promise(function resolve() {}, function reject() {})
         *          });
         *
         *
         * @param {string} name api function is registered with this name
         * @param {Function} handler function will be called
         * @param {MessagePort} [port]
         */
        registerApi(name: string, handler: (...params: any[]) => Promise<any> | any): void;
        /**
         * Unregister an api function
         * @param {string} name api function registered under this name
         */
        unregisterApi(name: string);
        /**
         * Check whether an api function is registered on the current connection.
         * @param {string} name api function registered under this name
         */
        isRegisteredApi(name: string);
        /**
         * Close the connection.
         * Removes handlers, closes port.
         */
        close(): void;
        /**
         * Register a handler which will be called when the connection is closed.
         * The handler will receive the connection as first argument.
         * @param handler
         */
        onClose(handler: (connection: Connection) => void): void;
        /**
         * Unregister a close handler.
         * Also see [[onClose]].
         *
         * @param handler
         */
        offClose(handler: (connection: Connection) => void): void;
    }

    /**
     * Interface for configuration of clients.
     * For security reasons it is recommended to supply values for the configuration.
     */
    export interface IClientConfig {
        /**
         * Client will check incoming post messages for the given origin. '*' is accepted and is the default value, but you should always set it to a specific origin.
         * The origin will be environment specific, so a different origin should be configured for TEST, INT and PROD environments.
         * Examples:
         * {'http://workplace-int.bmwgroup.net'} : will only allow connections from hosts of the workplace INT environment
         * {'*'} : would allow connections from every host, also outside the BMW environment
         */
        origin?: string;
        /**
         * A whitelist of client ids which are allowed to connect. Default is empty array, meaning that all clients can connect. The Host is managing the client ids.
         * In the workplace the client ids match the app names, e.g. "tlt" or "fls".
         */
        allowConnectFrom?: string[];
    }
}


declare var Messaging: messaging.MessagingStatic;

